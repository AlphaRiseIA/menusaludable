<?php
libxml_use_internal_errors(true);
$xml = simplexml_load_file(__DIR__ . '/xml/menu.xml');
if (!$xml) {
    echo "<h2>Error cargando XML</h2>";
    foreach (libxml_get_errors() as $error) {
        echo "<p>{$error->message}</p>";
    }
    exit;
}

// Mapa de iconos Font Awesome inspirado en documentación sacada de https://gist.github.com/anuislam/bc14eb036d8db39cd402c04fa9518bc7


$iconMap = [
    'vegano'      => 'fa-solid fa-leaf',
    'sin gluten'  => 'fa-solid fa-seedling',
    'carne'       => 'fa-solid fa-drumstick-bite',
    'marisco'     => 'fa-solid fa-fish',
    'frito'       => 'fa-solid fa-fire',
    'destacado'   => 'fa-solid fa-star',
    'vegetariano' => 'fa-solid fa-seedling'
];

function slugify($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    return strtolower($text);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Carta Japonesa</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="…" crossorigin="anonymous" referrerpolicy="no-referrer"/>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <div class="container">
    <h1 class="text-center my-4">Nuestra Carta Japonesa</h1>
    <div class="menu-grid">
      <?php
      foreach ($xml->children() as $sectionName => $section) {
          echo '<div class="category-title">' . ucfirst($sectionName) . '</div>';
          foreach ($section->plato as $plato) {
              $imgPath = 'assets/img/' . slugify($plato->nombre) . '.jpg';
              echo '<div class="menu-card">';
              if (file_exists(__DIR__ . '/' . $imgPath)) {
                  echo '<div class="thumb"><img src="' . htmlspecialchars($imgPath) . '" alt="' . htmlspecialchars($plato->nombre) . '"></div>';
              }
              echo '<div class="info">';
              echo '<h3>' . htmlspecialchars($plato->nombre) . '</h3>';
              echo '<p>' . htmlspecialchars($plato->descripcion) . '</p>';
              echo '<p>Calorías: ' . htmlspecialchars($plato->calorias) . '</p>';
              echo '<p class="price">' . htmlspecialchars($plato->precio) . ' €</p>';
              echo '<div class="caracts">';
              foreach ($plato->caracteristicas->item as $item) {
                  $key = (string)$item;
                  if (isset($iconMap[$key])) {
                      echo '<i class="' . $iconMap[$key] . '" title="' . htmlspecialchars($key) . '"></i>';
                  }
              }
              echo '</div>';
              echo '</div>';
              echo '</div>';
          }
      }
      ?>
    </div>
  </div>
</body>
</html>
