# Proyecto Carta Restaurante

Este proyecto muestra un menú de bar/restaurante usando XML, PHP, HTML y CSS (responsive).

**Estructura**:
- `xml/menu.xml`: Datos de los platos (20 entradas).
- `css/style.css`: Hoja de estilos única y responsive.
- `index.php`: Script principal para parsear y mostrar el menú.
- `assets/img/`: Imágenes opcionales de los platos.
- `assets/fonts/`: Fuentes locales (si se requiere).

**Despliegue**:
1. Sube todos los ficheros al hosting (por ejemplo, 000webhost o InfinityFree).
2. Asegúrate que `index.php` esté en la raíz pública.
3. Accede a la URL proporcionada y comprueba que el menú se carga correctamente.
